package com.ac_companion.wegner;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

//Ad-shit importieren
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

//Test-Banner ID ca-app-pub-3940256099942544/6300978111
//Admob-ID dieser App ist ca-app-pub-5899740383904630~9341712675
//Bottom_Banner ca-app-pub-5899740383904630/7815564939
//Fullscreen_unterbrecher ca-app-pub-5899740383904630/9096857012

public class MainActivity extends AppCompatActivity {
    private ImageButton butF, butI, butFo, butS, butD;
    public String language;
    //private Context context;
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Util.context=this.getApplicationContext();
        //Sprache abrufen
        language = Util.getLanguage();

        //mobile ads laden *würg*
        MobileAds.initialize(this, initializationStatus -> {
        });
        //bottom_banner laden
        mAdView = findViewById(R.id.bottombannerviewmain);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        //Unterbrechungswerbung vorbereiten
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        //Buttons initialisieren

        //Fische
        butF = (ImageButton) findViewById(R.id.buttonFish);
        butF.setOnClickListener(v -> {
            openFishView();
            //prüfen ob die unterbrechungswerbung geladen ist, wenn ja, dann zeige sie
            /*if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.");
            }*/
        });
        //Insekten
        butI = (ImageButton) findViewById(R.id.buttonInsects);
        butI.setOnClickListener(v -> {
            openInsectView();
            //prüfen ob die unterbrechungswerbung geladen ist, wenn ja, dann zeige sie
           /* if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.");
            }*/
        });
        //Fossils
        butFo = (ImageButton) findViewById(R.id.buttonFossils);
        butFo.setOnClickListener(v -> {
            openFossilView();
            //prüfen ob die unterbrechungswerbung geladen ist, wenn ja, dann zeige sie
           /* if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.");
            }*/
        });
        //Settings
        butS = (ImageButton) findViewById(R.id.buttonSettings);
        butS.setOnClickListener(v -> {
            openSettingsView();
            //prüfen ob die unterbrechungswerbung geladen ist, wenn ja, dann zeige sie
           /* if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.");
            }*/
        });
        //Discord
        butD = (ImageButton) findViewById(R.id.buttonDiscord);
        butD.setOnClickListener(v -> {
            Uri uri = Uri.parse("https://discord.gg/4Zcye47"); // missing 'http://' will cause crash
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        });

    }

    public void openFishView() {
        Intent intent = new Intent(this, FishCatchable.class);
        MainActivity.this.startActivity(intent);
    }
    public void openInsectView() {
        Intent intent = new Intent(this, InsectCatchable.class);
        MainActivity.this.startActivity(intent);
    }
    public void openFossilView() {
        Intent intent = new Intent(this, FossilCatchable.class);
        MainActivity.this.startActivity(intent);
    }
    public void openSettingsView() {
        Intent intent = new Intent(this, Settings.class);
        MainActivity.this.startActivity(intent);
    }
}
