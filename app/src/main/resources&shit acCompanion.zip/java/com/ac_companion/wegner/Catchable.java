package com.ac_companion.wegner;

public interface Catchable {
    public boolean isCatchable(int hour, int month, boolean southActive);
    public boolean isCatchableAtMonth(int month, boolean southActive);
    public String getName();
    public int getId();
}
